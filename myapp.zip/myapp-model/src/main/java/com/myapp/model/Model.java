package com.myapp.model;


public class Model {


}